# Deers on roads > 2022-12-16 10:24am
https://universe.roboflow.com/scalersai/deers-on-roads

Provided by a Roboflow user
License: CC BY 4.0

